# towers_game2d

Blog post: https://alfilatov.com/posts/pishiem-ighru-na-html5-slash-js/
